import { supabase } from "@/lib/supabase/client";

import { getAccessToken } from "@/lib/auth/session";

import type {
  DashboardSummaryResponse,
} from "@/types/dashboard/summary";

const FUNCTION_NAME =
  "dashboard-summary";

export async function getDashboardSummary(): Promise<DashboardSummaryResponse> {

  const token =
    await getAccessToken();

  const {
    data,
    error,
  } = await supabase.functions.invoke(
    FUNCTION_NAME,
    {
      method: "POST",

      headers: {
        Authorization: `Bearer ${token}`,
      },
    },
  );

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Dashboard summary returned an empty response.",
    );
  }

  if (data.success !== true) {
    throw new Error(
      data.error?.message ??
      "Dashboard summary failed.",
    );
  }

  return data as DashboardSummaryResponse;

}