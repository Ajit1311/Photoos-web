import {
  QueryClient,
} from "@tanstack/react-query";

export const queryClient =
  new QueryClient({

    defaultOptions: {

      queries: {

        retry: 2,

        staleTime:
          1000 * 60,

        gcTime:
          1000 *
          60 *
          10,

        refetchOnWindowFocus:
          false,

      },

    },

  });